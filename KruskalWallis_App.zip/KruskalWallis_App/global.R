# ============================================================================
# GLOBAL.R - CONFIGURACIONES GLOBALES
# Aplicación Shiny: Análisis de Kruskal-Wallis
# ============================================================================

# Cargar librerías necesarias
library(shiny)
library(shinythemes)
library(ggplot2)
library(plotly)
library(dplyr)
library(DT)
library(FSA)

# Configuración de opciones globales
options(
  shiny.maxRequestSize = 30*1024^2,  # Límite de carga: 30MB
  scipen = 999,                       # Desactivar notación científica
  digits = 4                          # Redondeo a 4 decimales
)

# Configuración de idioma para mensajes de error
Sys.setlocale("LC_TIME", "es_ES.UTF-8")

# Definir paletas de colores personalizadas
paletas_custom <- list(
  viridis = c("#440154", "#31688e", "#35b779", "#fde724"),
  pastel = c("#FFB6C1", "#87CEEB", "#98FB98", "#FFD700"),
  profesional = c("#2E86AB", "#A23B72", "#F18F01", "#C73E1D")
)

# Mensajes de ayuda contextuales
mensajes_ayuda <- list(
  kruskal = "La prueba de Kruskal-Wallis evalúa si las medianas de varios grupos son iguales.",
  posthoc = "El test de Dunn identifica qué pares de grupos son significativamente diferentes.",
  alpha = "Nivel de significancia: probabilidad de rechazar H0 cuando es verdadera.",
  csv = "Formato CSV requerido: una columna para grupos y otra para valores numéricos."
)

# Función para validar datos
validar_datos <- function(df) {
  errores <- c()
  
  # Verificar que existan datos
  if (is.null(df) || nrow(df) == 0) {
    errores <- c(errores, "No hay datos cargados")
  }
  
  # Verificar número mínimo de observaciones
  if (nrow(df) < 3) {
    errores <- c(errores, "Se requieren al menos 3 observaciones")
  }
  
  # Verificar número de grupos
  if (length(unique(df$Grupo)) < 2) {
    errores <- c(errores, "Se requieren al menos 2 grupos diferentes")
  }
  
  # Verificar valores numéricos
  if (!is.numeric(df$Valor)) {
    errores <- c(errores, "La columna de valores debe ser numérica")
  }
  
  # Verificar NA
  if (any(is.na(df))) {
    errores <- c(errores, "Existen valores faltantes (NA) en los datos")
  }
  
  return(errores)
}

# Función para calcular estadísticas descriptivas por grupo
estadisticas_grupo <- function(df) {
  df %>%
    group_by(Grupo) %>%
    summarise(
      n = n(),
      Media = mean(Valor, na.rm = TRUE),
      Mediana = median(Valor, na.rm = TRUE),
      DE = sd(Valor, na.rm = TRUE),
      Min = min(Valor, na.rm = TRUE),
      Max = max(Valor, na.rm = TRUE),
      Q1 = quantile(Valor, 0.25, na.rm = TRUE),
      Q3 = quantile(Valor, 0.75, na.rm = TRUE)
    ) %>%
    mutate_if(is.numeric, round, 2)
}

# Función para interpretar tamaño del efecto
interpretar_efecto <- function(h_stat, n_total, k_grupos) {
  # Calcular eta cuadrado (medida de tamaño del efecto)
  eta_sq <- (h_stat - k_grupos + 1) / (n_total - k_grupos)
  
  if (eta_sq < 0.01) {
    return("Efecto muy pequeño")
  } else if (eta_sq < 0.06) {
    return("Efecto pequeño")
  } else if (eta_sq < 0.14) {
    return("Efecto mediano")
  } else {
    return("Efecto grande")
  }
}

# Mensaje de bienvenida
cat("\n")
cat("=======================================================\n")
cat("  APLICACIÓN SHINY: ANÁLISIS DE KRUSKAL-WALLIS\n")
cat("=======================================================\n")
cat("  Versión: 1.0.0\n")
cat("  Autor: Análisis Estadístico Interactivo\n")
cat("  Fecha:", as.character(Sys.Date()), "\n")
cat("=======================================================\n")
cat("\n")