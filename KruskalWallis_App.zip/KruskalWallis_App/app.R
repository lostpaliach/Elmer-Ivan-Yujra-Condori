# ============================================================================
# APLICACIÓN SHINY: ANÁLISIS DE KRUSKAL-WALLIS
# Prueba no paramétrica para comparación de múltiples grupos
# ============================================================================

library(shiny)
library(shinythemes)
library(ggplot2)
library(plotly)
library(dplyr)
library(DT)
library(FSA)

# ============================================================================
# DATOS DE EJEMPLO PREDEFINIDOS
# ============================================================================

ejemplo1 <- data.frame(
  Grupo = rep(c("Tratamiento A", "Tratamiento B", "Control"), each = 30),
  Puntuacion = c(rnorm(30, 85, 12), rnorm(30, 92, 10), rnorm(30, 78, 15))
)

ejemplo2 <- data.frame(
  Metodo = rep(c("Método X", "Método Y", "Método Z"), each = 25),
  Tiempo = c(rexp(25, 0.5), rexp(25, 0.3), rexp(25, 0.7))
)

ejemplo3 <- data.frame(
  Departamento = rep(c("Ventas", "TI", "RH", "Marketing"), each = 20),
  Satisfaccion = c(runif(20, 60, 90), runif(20, 70, 95), 
                   runif(20, 50, 80), runif(20, 65, 85))
)

# ============================================================================
# INTERFAZ DE USUARIO (UI)
# ============================================================================

ui <- fluidPage(
  theme = shinytheme("flatly"),
  
  # CSS personalizado
  tags$head(
    tags$style(HTML("
      .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        border-radius: 10px;
        margin-bottom: 20px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      }
      .info-box {
        background-color: #f8f9fa;
        border-left: 4px solid #667eea;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
      }
      .result-box {
        background-color: #e7f3ff;
        border: 2px solid #2196F3;
        padding: 20px;
        border-radius: 8px;
        margin: 15px 0;
      }
      .success-box {
        background-color: #d4edda;
        border: 2px solid #28a745;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
      }
      .warning-box {
        background-color: #fff3cd;
        border: 2px solid #ffc107;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
      }
      .btn-analizar {
        background-color: #667eea;
        color: white;
        font-weight: bold;
        padding: 10px 30px;
        font-size: 16px;
      }
      .btn-analizar:hover {
        background-color: #5568d3;
      }
    "))
  ),
  
  # Encabezado
  div(class = "main-header",
      h1("📊 Análisis de Kruskal-Wallis", style = "margin: 0;"),
      p("Prueba no paramétrica para comparación de múltiples grupos independientes", 
        style = "margin-top: 10px; font-size: 16px;")
  ),
  
  # Layout principal
  sidebarLayout(
    
    # ========================================================================
    # PANEL LATERAL
    # ========================================================================
    sidebarPanel(
      width = 3,
      
      h4("⚙️ Configuración del Análisis"),
      hr(),
      
      # Selector de fuente de datos
      radioButtons(
        "fuente_datos",
        "Fuente de Datos:",
        choices = c("Datos de Ejemplo" = "ejemplo", 
                    "Subir Datos CSV" = "csv"),
        selected = "ejemplo"
      ),
      
      # Opciones para datos de ejemplo
      conditionalPanel(
        condition = "input.fuente_datos == 'ejemplo'",
        selectInput(
          "dataset_ejemplo",
          "Seleccionar Dataset:",
          choices = c(
            "Ejemplo 1: Tratamientos (n=90)" = "ej1",
            "Ejemplo 2: Métodos (n=75)" = "ej2",
            "Ejemplo 3: Departamentos (n=80)" = "ej3"
          )
        ),
        div(class = "info-box",
            icon("info-circle"),
            " Los datos de ejemplo están listos para análisis inmediato."
        )
      ),
      
      # Opciones para cargar CSV
      conditionalPanel(
        condition = "input.fuente_datos == 'csv'",
        fileInput(
          "archivo_csv",
          "Cargar archivo CSV:",
          accept = c(".csv", ".txt"),
          buttonLabel = "Examinar...",
          placeholder = "Ningún archivo seleccionado"
        ),
        uiOutput("ui_columna_grupo"),
        uiOutput("ui_columna_valor"),
        div(class = "info-box",
            icon("lightbulb"),
            " El CSV debe tener una columna para grupos y otra para valores."
        )
      ),
      
      hr(),
      
      # Nivel de significancia
      sliderInput(
        "alpha",
        "Nivel de Significancia (α):",
        min = 0.01,
        max = 0.10,
        value = 0.05,
        step = 0.01
      ),
      
      # Checkbox para análisis post-hoc
      checkboxInput(
        "posthoc",
        "Mostrar análisis post-hoc (comparaciones por pares)",
        value = FALSE
      ),
      
      # Selector de colores
      selectInput(
        "paleta_colores",
        "Paleta de Colores:",
        choices = c("Viridis" = "viridis",
                    "Set2" = "Set2",
                    "Accent" = "Accent",
                    "Dark2" = "Dark2")
      ),
      
      hr(),
      
      # Botón de análisis
      actionButton(
        "ejecutar",
        "🚀 Ejecutar Análisis",
        class = "btn-analizar btn-block",
        icon = icon("play-circle")
      ),
      
      br(), br(),
      
      # Botón de reinicio
      actionButton(
        "reiniciar",
        "🔄 Reiniciar",
        class = "btn btn-warning btn-block"
      )
    ),
    
    # ========================================================================
    # PANEL PRINCIPAL
    # ========================================================================
    mainPanel(
      width = 9,
      
      tabsetPanel(
        id = "pestanas",
        type = "tabs",
        
        # ====================================================================
        # PESTAÑA 1: DATOS
        # ====================================================================
        tabPanel(
          "📋 Datos",
          br(),
          h4("Vista de Datos Cargados"),
          hr(),
          uiOutput("info_datos"),
          br(),
          DTOutput("tabla_datos"),
          br(),
          downloadButton("descargar_datos", "Descargar Datos", 
                        class = "btn-info")
        ),
        
        # ====================================================================
        # PESTAÑA 2: GRÁFICOS
        # ====================================================================
        tabPanel(
          "📊 Gráficos",
          br(),
          h4("Visualización de Datos por Grupos"),
          hr(),
          
          fluidRow(
            column(12,
                   plotlyOutput("boxplot", height = "450px")
            )
          ),
          
          br(),
          
          fluidRow(
            column(12,
                   plotlyOutput("densidad", height = "400px")
            )
          )
        ),
        
        # ====================================================================
        # PESTAÑA 3: RESULTADOS KRUSKAL-WALLIS
        # ====================================================================
        tabPanel(
          "📈 Resultados Kruskal-Wallis",
          br(),
          h4("Resultados de la Prueba de Kruskal-Wallis"),
          hr(),
          uiOutput("resultados_kruskal"),
          br(),
          uiOutput("interpretacion"),
          br(),
          downloadButton("descargar_resultados", "Descargar Resultados", 
                        class = "btn-success")
        ),
        
        # ====================================================================
        # PESTAÑA 4: ANÁLISIS POST-HOC
        # ====================================================================
        tabPanel(
          "🔍 Análisis Post-Hoc",
          br(),
          h4("Comparaciones por Pares (Test de Dunn)"),
          hr(),
          uiOutput("info_posthoc"),
          br(),
          DTOutput("tabla_posthoc"),
          br(),
          plotlyOutput("grafico_posthoc", height = "400px")
        ),
        
        # ====================================================================
        # PESTAÑA 5: SUPUESTOS
        # ====================================================================
        tabPanel(
          "ℹ️ Supuestos y Ayuda",
          br(),
          h4("Supuestos de la Prueba de Kruskal-Wallis"),
          hr(),
          
          div(class = "info-box",
              h5("📌 ¿Qué es la prueba de Kruskal-Wallis?"),
              p("La prueba de Kruskal-Wallis es una alternativa no paramétrica al ANOVA de 
                una vía. Se utiliza para determinar si existen diferencias significativas 
                entre tres o más grupos independientes basándose en los rangos de los datos.")
          ),
          
          br(),
          
          div(class = "info-box",
              h5("✅ Supuestos de la prueba:"),
              tags$ol(
                tags$li(strong("Independencia:"), " Las observaciones deben ser independientes 
                        entre sí."),
                tags$li(strong("Variable ordinal o continua:"), " La variable dependiente debe 
                        ser al menos ordinal."),
                tags$li(strong("Grupos independientes:"), " Los grupos que se comparan deben 
                        ser independientes (muestras no relacionadas)."),
                tags$li(strong("Forma de distribución similar:"), " Las distribuciones de cada 
                        grupo deben tener formas similares para interpretar los resultados como 
                        diferencias en medianas.")
              )
          ),
          
          br(),
          
          div(class = "info-box",
              h5("📊 Interpretación de resultados:"),
              tags$ul(
                tags$li(strong("Estadístico H:"), " Mide la diferencia entre los rangos 
                        promedio de los grupos. Valores más altos indican mayores diferencias."),
                tags$li(strong("Valor p:"), " Si p < α (ej. 0.05), rechazamos la hipótesis 
                        nula y concluimos que al menos un grupo difiere de los demás."),
                tags$li(strong("Análisis post-hoc:"), " Si el resultado es significativo, 
                        use pruebas post-hoc (como el test de Dunn) para identificar qué 
                        pares de grupos son diferentes.")
              )
          ),
          
          br(),
          
          div(class = "success-box",
              h5("💡 Consejos de uso:"),
              tags$ul(
                tags$li("Comience con los datos de ejemplo para familiarizarse con la aplicación."),
                tags$li("Para datos propios, asegúrese de que el CSV tenga encabezados claros."),
                tags$li("Active el análisis post-hoc solo si el resultado principal es significativo."),
                tags$li("Descargue los resultados para incluirlos en sus informes.")
              )
          )
        )
      )
    )
  ),
  
  # Pie de página
  hr(),
  div(style = "text-align: center; color: #666; padding: 20px;",
      p("Desarrollado con", icon("heart"), "usando R Shiny"),
      p("© 2025 - Análisis Estadístico Interactivo")
  )
)

# ============================================================================
# SERVIDOR
# ============================================================================

server <- function(input, output, session) {
  
  # ==========================================================================
  # VALORES REACTIVOS
  # ==========================================================================
  
  valores <- reactiveValues(
    datos = NULL,
    resultado_kw = NULL,
    posthoc_resultado = NULL,
    ejecutado = FALSE
  )
  
  # ==========================================================================
  # CARGA Y MANEJO DE DATOS
  # ==========================================================================
  
  # UI dinámica para selección de columnas (CSV)
  output$ui_columna_grupo <- renderUI({
    req(input$archivo_csv)
    df <- read.csv(input$archivo_csv$datapath, stringsAsFactors = FALSE)
    selectInput("col_grupo", "Columna de Grupos:", choices = names(df))
  })
  
  output$ui_columna_valor <- renderUI({
    req(input$archivo_csv)
    df <- read.csv(input$archivo_csv$datapath, stringsAsFactors = FALSE)
    selectInput("col_valor", "Columna de Valores:", choices = names(df))
  })
  
  # Datos reactivos
  datos_reactivos <- reactive({
    if (input$fuente_datos == "ejemplo") {
      # Datos de ejemplo
      df <- switch(input$dataset_ejemplo,
                   "ej1" = ejemplo1,
                   "ej2" = ejemplo2,
                   "ej3" = ejemplo3)
      
      # Renombrar columnas a nombres estándar
      names(df) <- c("Grupo", "Valor")
      df$Grupo <- as.factor(df$Grupo)
      return(df)
      
    } else {
      # Datos desde CSV
      req(input$archivo_csv, input$col_grupo, input$col_valor)
      
      df <- tryCatch({
        read.csv(input$archivo_csv$datapath, stringsAsFactors = FALSE)
      }, error = function(e) {
        showNotification("Error al leer el archivo CSV", type = "error")
        return(NULL)
      })
      
      req(df)
      
      # Seleccionar y renombrar columnas
      df_final <- data.frame(
        Grupo = as.factor(df[[input$col_grupo]]),
        Valor = as.numeric(df[[input$col_valor]])
      )
      
      # Validar datos
      if (any(is.na(df_final$Valor))) {
        showNotification("Advertencia: Algunos valores no son numéricos y fueron eliminados", 
                        type = "warning")
        df_final <- df_final[!is.na(df_final$Valor), ]
      }
      
      return(df_final)
    }
  })
  
  # ==========================================================================
  # EJECUTAR ANÁLISIS
  # ==========================================================================
  
  observeEvent(input$ejecutar, {
    req(datos_reactivos())
    
    df <- datos_reactivos()
    
    # Validaciones
    if (nrow(df) < 3) {
      showNotification("Error: Se necesitan al menos 3 observaciones", type = "error")
      return()
    }
    
    if (length(unique(df$Grupo)) < 2) {
      showNotification("Error: Se necesitan al menos 2 grupos diferentes", type = "error")
      return()
    }
    
    # Ejecutar Kruskal-Wallis
    valores$resultado_kw <- tryCatch({
      kruskal.test(Valor ~ Grupo, data = df)
    }, error = function(e) {
      showNotification("Error al ejecutar la prueba de Kruskal-Wallis", type = "error")
      return(NULL)
    })
    
    # Ejecutar post-hoc si está activado
    if (input$posthoc) {
      valores$posthoc_resultado <- tryCatch({
        dunnTest(Valor ~ Grupo, data = df, method = "bonferroni")
      }, error = function(e) {
        showNotification("Error al ejecutar el análisis post-hoc", type = "warning")
        return(NULL)
      })
    }
    
    valores$ejecutado <- TRUE
    valores$datos <- df
    
    showNotification("✅ Análisis completado exitosamente", type = "message", duration = 3)
  })
  
  # ==========================================================================
  # REINICIAR APLICACIÓN
  # ==========================================================================
  
  observeEvent(input$reiniciar, {
    valores$datos <- NULL
    valores$resultado_kw <- NULL
    valores$posthoc_resultado <- NULL
    valores$ejecutado <- FALSE
    updateTabsetPanel(session, "pestanas", selected = "📋 Datos")
    showNotification("Aplicación reiniciada", type = "message")
  })
  
  # ==========================================================================
  # PESTAÑA: DATOS
  # ==========================================================================
  
  output$info_datos <- renderUI({
    df <- datos_reactivos()
    req(df)
    
    n_total <- nrow(df)
    n_grupos <- length(unique(df$Grupo))
    grupos <- unique(df$Grupo)
    
    div(class = "result-box",
        h5("📊 Resumen de los datos:"),
        tags$ul(
          tags$li(strong("Total de observaciones:"), n_total),
          tags$li(strong("Número de grupos:"), n_grupos),
          tags$li(strong("Grupos:"), paste(grupos, collapse = ", "))
        )
    )
  })
  
  output$tabla_datos <- renderDT({
    req(datos_reactivos())
    datatable(
      datos_reactivos(),
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        language = list(url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Spanish.json')
      ),
      rownames = FALSE
    )
  })
  
  output$descargar_datos <- downloadHandler(
    filename = function() {
      paste("datos_kruskal_", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(datos_reactivos(), file, row.names = FALSE)
    }
  )
  
  # ==========================================================================
  # PESTAÑA: GRÁFICOS
  # ==========================================================================
  
  output$boxplot <- renderPlotly({
    req(datos_reactivos())
    df <- datos_reactivos()
    
    p <- ggplot(df, aes(x = Grupo, y = Valor, fill = Grupo)) +
      geom_boxplot(alpha = 0.7, outlier.shape = 21, outlier.size = 3) +
      geom_jitter(width = 0.2, alpha = 0.3, size = 2) +
      scale_fill_brewer(palette = input$paleta_colores) +
      labs(
        title = "Diagrama de Cajas por Grupo",
        x = "Grupo",
        y = "Valor",
        subtitle = paste("n =", nrow(df))
      ) +
      theme_minimal(base_size = 14) +
      theme(
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        axis.text.x = element_text(angle = 45, hjust = 1)
      )
    
    ggplotly(p, tooltip = c("y", "x")) %>%
      layout(hovermode = "closest")
  })
  
  output$densidad <- renderPlotly({
    req(datos_reactivos())
    df <- datos_reactivos()
    
    p <- ggplot(df, aes(x = Valor, fill = Grupo)) +
      geom_density(alpha = 0.5) +
      scale_fill_brewer(palette = input$paleta_colores) +
      labs(
        title = "Distribución de Valores por Grupo",
        x = "Valor",
        y = "Densidad"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, face = "bold"),
        legend.position = "right"
      )
    
    ggplotly(p)
  })
  
  # ==========================================================================
  # PESTAÑA: RESULTADOS KRUSKAL-WALLIS
  # ==========================================================================
  
  output$resultados_kruskal <- renderUI({
    req(valores$ejecutado, valores$resultado_kw)
    
    resultado <- valores$resultado_kw
    h_stat <- round(resultado$statistic, 4)
    p_valor <- resultado$p.value
    df_param <- resultado$parameter
    
    div(
      div(class = "result-box",
          h5("📊 Estadísticos de la Prueba:"),
          tags$table(class = "table table-striped",
                     tags$tr(
                       tags$td(strong("Estadístico H:")),
                       tags$td(h_stat)
                     ),
                     tags$tr(
                       tags$td(strong("Grados de libertad:")),
                       tags$td(df_param)
                     ),
                     tags$tr(
                       tags$td(strong("Valor p:")),
                       tags$td(ifelse(p_valor < 0.001, "< 0.001", round(p_valor, 4)))
                     ),
                     tags$tr(
                       tags$td(strong("Nivel de significancia (α):")),
                       tags$td(input$alpha)
                     )
          )
      )
    )
  })
  
  output$interpretacion <- renderUI({
    req(valores$ejecutado, valores$resultado_kw)
    
    p_valor <- valores$resultado_kw$p.value
    alpha <- input$alpha
    
    if (p_valor < alpha) {
      div(class = "success-box",
          h5("✅ Conclusión:"),
          p(strong("Se rechaza la hipótesis nula.")),
          p("Existe evidencia estadísticamente significativa (p ", 
            ifelse(p_valor < 0.001, "< 0.001", paste("=", round(p_valor, 4))),
            ") para concluir que al menos uno de los grupos difiere significativamente 
            de los demás en términos de sus medianas."),
          br(),
          p(strong("Recomendación:"), " Active el análisis post-hoc para identificar 
            qué pares de grupos son diferentes.")
      )
    } else {
      div(class = "warning-box",
          h5("⚠️ Conclusión:"),
          p(strong("No se rechaza la hipótesis nula.")),
          p("No existe evidencia estadísticamente significativa (p = ", 
            round(p_valor, 4), ") para concluir que los grupos difieren en 
            sus medianas al nivel de significancia α = ", alpha, "."),
          br(),
          p("Las diferencias observadas entre los grupos podrían deberse al azar.")
      )
    }
  })
  
  output$descargar_resultados <- downloadHandler(
    filename = function() {
      paste("resultados_kruskal_", Sys.Date(), ".txt", sep = "")
    },
    content = function(file) {
      req(valores$resultado_kw)
      sink(file)
      cat("========================================\n")
      cat("RESULTADOS DE LA PRUEBA DE KRUSKAL-WALLIS\n")
      cat("========================================\n\n")
      cat("Fecha:", as.character(Sys.Date()), "\n\n")
      print(valores$resultado_kw)
      cat("\n\nNivel de significancia: ", input$alpha, "\n")
      cat("Conclusión: ", 
          ifelse(valores$resultado_kw$p.value < input$alpha, 
                 "Se rechaza H0", "No se rechaza H0"), "\n")
      sink()
    }
  )
  
  # ==========================================================================
  # PESTAÑA: ANÁLISIS POST-HOC
  # ==========================================================================
  
  output$info_posthoc <- renderUI({
    if (!input$posthoc) {
      div(class = "warning-box",
          h5("⚠️ Análisis post-hoc no activado"),
          p("Active la opción 'Mostrar análisis post-hoc' en el panel lateral 
            y ejecute el análisis nuevamente para ver las comparaciones por pares.")
      )
    } else if (!valores$ejecutado) {
      div(class = "info-box",
          h5("ℹ️ Esperando análisis"),
          p("Presione 'Ejecutar Análisis' para ver los resultados post-hoc.")
      )
    } else {
      div(class = "info-box",
          h5("📊 Test de Dunn con corrección de Bonferroni"),
          p("Este análisis identifica qué pares de grupos son significativamente diferentes. 
            Se aplicó la corrección de Bonferroni para controlar el error tipo I en 
            comparaciones múltiples.")
      )
    }
  })
  
  output$tabla_posthoc <- renderDT({
    req(input$posthoc, valores$ejecutado, valores$posthoc_resultado)
    
    resultado <- valores$posthoc_resultado$res
    
    # Formatear tabla
    tabla <- resultado %>%
      mutate(
        `Valor p` = ifelse(P.adj < 0.001, "< 0.001", round(P.adj, 4)),
        Significativo = ifelse(P.adj < input$alpha, "✓ Sí", "✗ No")
      ) %>%
      select(Comparación = Comparison, Z, `Valor p`, Significativo)
    
    datatable(
      tabla,
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        language = list(url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Spanish.json')
      ),
      rownames = FALSE
    ) %>%
      formatStyle(
        'Significativo',
        backgroundColor = styleEqual(c('✓ Sí', '✗ No'), c('#d4edda', '#f8d7da'))
      )
  })
  
  output$grafico_posthoc <- renderPlotly({
    req(input$posthoc, valores$ejecutado, valores$posthoc_resultado)
    
    resultado <- valores$posthoc_resultado$res
    
    # Preparar datos para gráfico
    resultado$Significativo <- ifelse(resultado$P.adj < input$alpha, "Significativo", "No significativo")
    resultado$Comparación <- factor(resultado$Comparison, levels = rev(resultado$Comparison))
    
    p <- ggplot(resultado, aes(x = Z, y = Comparación, color = Significativo)) +
      geom_point(size = 4) +
      geom_vline(xintercept = 0, linetype = "dashed", color = "gray50") +
      scale_color_manual(values = c("Significativo" = "#28a745", "No significativo" = "#dc3545")) +
      labs(
        title = "Estadísticos Z de Comparaciones Post-Hoc",
        x = "Estadístico Z",
        y = "Comparación",
        color = "Resultado"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, face = "bold"),
        legend.position = "top"
      )
    
    ggplotly(p)
  })
}

# ============================================================================
# EJECUTAR APLICACIÓN
# ============================================================================

shinyApp(ui = ui, server = server)