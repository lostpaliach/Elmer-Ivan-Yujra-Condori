# ============================================================================
# SCRIPT DE INSTALACIÓN DE PAQUETES
# Aplicación Shiny: Análisis de Kruskal-Wallis
# ============================================================================

cat("\n")
cat("====================================================================\n")
cat("  INSTALACIÓN DE PAQUETES PARA APLICACIÓN KRUSKAL-WALLIS\n")
cat("====================================================================\n\n")

# Lista de paquetes necesarios
paquetes_necesarios <- c(
  "shiny",
  "shinythemes",
  "ggplot2",
  "plotly",
  "dplyr",
  "DT",
  "FSA"
)

# Paquetes opcionales (para funcionalidades adicionales)
paquetes_opcionales <- c(
  "knitr",
  "rmarkdown",
  "writexl"
)

# ----------------------------------------------------------------------------
# FUNCIÓN PARA INSTALAR PAQUETES
# ----------------------------------------------------------------------------

instalar_si_falta <- function(paquetes, tipo = "necesarios") {
  cat(paste0("Verificando paquetes ", tipo, "...\n\n"))
  
  # Identificar paquetes faltantes
  paquetes_instalados <- installed.packages()[, "Package"]
  paquetes_faltantes <- paquetes[!(paquetes %in% paquetes_instalados)]
  
  if (length(paquetes_faltantes) == 0) {
    cat(paste0("✅ Todos los paquetes ", tipo, " ya están instalados.\n\n"))
    return(TRUE)
  }
  
  # Mostrar paquetes a instalar
  cat(paste0("📦 Paquetes ", tipo, " a instalar:\n"))
  cat(paste0("   - ", paquetes_faltantes, collapse = "\n"), "\n\n")
  
  # Preguntar confirmación para paquetes opcionales
  if (tipo == "opcionales") {
    respuesta <- readline(prompt = "¿Desea instalar estos paquetes opcionales? (s/n): ")
    if (tolower(respuesta) != "s") {
      cat("⏭️  Saltando instalación de paquetes opcionales.\n\n")
      return(FALSE)
    }
  }
  
  # Instalar paquetes
  cat("🔄 Instalando paquetes...\n")
  tryCatch({
    install.packages(paquetes_faltantes, 
                     dependencies = TRUE,
                     repos = "https://cran.r-project.org")
    cat("✅ Instalación completada exitosamente!\n\n")
    return(TRUE)
  }, error = function(e) {
    cat("❌ Error durante la instalación:\n")
    cat(paste0("   ", e$message, "\n\n"))
    return(FALSE)
  })
}

# ----------------------------------------------------------------------------
# VERIFICAR VERSIÓN DE R
# ----------------------------------------------------------------------------

version_r <- as.numeric(R.version$major) + as.numeric(R.version$minor) / 10

cat("Versión de R detectada:", version_r, "\n")

if (version_r < 4.0) {
  cat("⚠️  ADVERTENCIA: Se recomienda R >= 4.0.0\n")
  cat("   Algunos paquetes podrían no funcionar correctamente.\n\n")
  respuesta <- readline(prompt = "¿Desea continuar de todos modos? (s/n): ")
  if (tolower(respuesta) != "s") {
    stop("Instalación cancelada por el usuario.")
  }
} else {
  cat("✅ Versión de R compatible.\n\n")
}

# ----------------------------------------------------------------------------
# INSTALAR PAQUETES NECESARIOS
# ----------------------------------------------------------------------------

exito_necesarios <- instalar_si_falta(paquetes_necesarios, "necesarios")

# ----------------------------------------------------------------------------
# INSTALAR PAQUETES OPCIONALES
# ----------------------------------------------------------------------------

instalar_si_falta(paquetes_opcionales, "opcionales")

# ----------------------------------------------------------------------------
# VERIFICACIÓN FINAL
# ----------------------------------------------------------------------------

cat("====================================================================\n")
cat("  VERIFICACIÓN FINAL DE INSTALACIÓN\n")
cat("====================================================================\n\n")

verificar_paquetes <- function(paquetes) {
  resultados <- sapply(paquetes, function(pkg) {
    if (require(pkg, character.only = TRUE, quietly = TRUE)) {
      version <- packageVersion(pkg)
      cat(sprintf("✅ %-15s (v%s)\n", pkg, version))
      return(TRUE)
    } else {
      cat(sprintf("❌ %-15s (NO INSTALADO)\n", pkg))
      return(FALSE)
    }
  })
  return(all(resultados))
}

cat("Paquetes necesarios:\n")
todos_instalados <- verificar_paquetes(paquetes_necesarios)

cat("\n")

# ----------------------------------------------------------------------------
# MENSAJE FINAL
# ----------------------------------------------------------------------------

cat("====================================================================\n")

if (todos_instalados) {
  cat("✅ ¡INSTALACIÓN COMPLETADA EXITOSAMENTE!\n")
  cat("====================================================================\n\n")
  cat("La aplicación está lista para ejecutarse.\n")
  cat("Para iniciar la aplicación, ejecuta:\n\n")
  cat("  shiny::runApp('app.R')\n\n")
  cat("O abre app.R en RStudio y haz clic en 'Run App'\n\n")
} else {
  cat("⚠️  INSTALACIÓN INCOMPLETA\n")
  cat("====================================================================\n\n")
  cat("Algunos paquetes necesarios no se instalaron correctamente.\n")
  cat("Por favor, instala manualmente los paquetes faltantes con:\n\n")
  cat("  install.packages(c('nombre_paquete1', 'nombre_paquete2'))\n\n")
}

cat("====================================================================\n\n")

# ----------------------------------------------------------------------------
# GUARDAR LOG DE INSTALACIÓN
# ----------------------------------------------------------------------------

log_file <- "installation_log.txt"
sink(log_file)
cat("Log de Instalación - Aplicación Kruskal-Wallis\n")
cat("Fecha:", as.character(Sys.time()), "\n")
cat("Versión de R:", R.version.string, "\n\n")
cat("Paquetes instalados:\n")
print(installed.packages()[paquetes_necesarios, c("Package", "Version")])
sink()

cat("📄 Log de instalación guardado en:", log_file, "\n\n")