# ============================================================================
# SCRIPT DE DESPLIEGUE A SHINYAPPS.IO
# Aplicación Shiny: Análisis de Kruskal-Wallis
# ============================================================================

# Este script facilita el despliegue de la aplicación en shinyapps.io

cat("\n")
cat("====================================================================\n")
cat("  DESPLIEGUE EN SHINYAPPS.IO\n")
cat("  Aplicación: Análisis de Kruskal-Wallis\n")
cat("====================================================================\n\n")

# ----------------------------------------------------------------------------
# PASO 1: VERIFICAR E INSTALAR RSCONNECT
# ----------------------------------------------------------------------------

cat("📦 Paso 1: Verificando paquete rsconnect...\n")

if (!require("rsconnect", quietly = TRUE)) {
  cat("   Instalando rsconnect...\n")
  install.packages("rsconnect")
  library(rsconnect)
  cat("   ✅ rsconnect instalado correctamente\n\n")
} else {
  library(rsconnect)
  cat("   ✅ rsconnect ya está instalado\n\n")
}

# ----------------------------------------------------------------------------
# PASO 2: VERIFICAR PAQUETES NECESARIOS
# ----------------------------------------------------------------------------

cat("📦 Paso 2: Verificando dependencias de la aplicación...\n")

paquetes_requeridos <- c("shiny", "shinythemes", "ggplot2", "plotly", 
                         "dplyr", "DT", "FSA")

paquetes_faltantes <- paquetes_requeridos[!(paquetes_requeridos %in% 
                                            installed.packages()[, "Package"])]

if (length(paquetes_faltantes) > 0) {
  cat("   ⚠️  Paquetes faltantes detectados:\n")
  cat(paste0("      - ", paquetes_faltantes, collapse = "\n"), "\n")
  cat("   Por favor, ejecuta install_packages.R primero\n\n")
  stop("Instalación detenida: paquetes faltantes")
} else {
  cat("   ✅ Todas las dependencias están instaladas\n\n")
}

# ----------------------------------------------------------------------------
# PASO 3: CONFIGURAR CUENTA (SI ES NECESARIO)
# ----------------------------------------------------------------------------

cat("🔐 Paso 3: Configuración de cuenta de shinyapps.io\n")

# Verificar si ya hay cuentas configuradas
cuentas <- accounts()

if (nrow(cuentas) == 0) {
  cat("\n")
  cat("   ⚠️  No se encontró ninguna cuenta configurada.\n")
  cat("   Por favor, configura tu cuenta primero:\n\n")
  cat("   1. Ve a https://www.shinyapps.io/admin/#/tokens\n")
  cat("   2. Copia tu token y secret\n")
  cat("   3. Ejecuta:\n\n")
  cat("      rsconnect::setAccountInfo(\n")
  cat("        name = 'tu_usuario',\n")
  cat("        token = 'tu_token',\n")
  cat("        secret = 'tu_secret'\n")
  cat("      )\n\n")
  
  respuesta <- readline(prompt = "¿Ya configuraste tu cuenta? (s/n): ")
  
  if (tolower(respuesta) != "s") {
    stop("Despliegue cancelado. Por favor, configura tu cuenta primero.")
  }
  
  # Recargar cuentas después de la configuración
  cuentas <- accounts()
  
  if (nrow(cuentas) == 0) {
    stop("No se encontró ninguna cuenta. Configura tu cuenta y vuelve a intentarlo.")
  }
}

cat("   ✅ Cuenta encontrada:", cuentas$name[1], "\n\n")

# ----------------------------------------------------------------------------
# PASO 4: CONFIGURAR OPCIONES DE DESPLIEGUE
# ----------------------------------------------------------------------------

cat("⚙️  Paso 4: Configurando opciones de despliegue...\n\n")

# Nombre de la aplicación (puedes personalizarlo)
nombre_app_default <- "kruskal-wallis-app"

cat("   Nombre sugerido para la aplicación:", nombre_app_default, "\n")
respuesta_nombre <- readline(prompt = "   ¿Usar este nombre? (s/n): ")

if (tolower(respuesta_nombre) == "s") {
  nombre_app <- nombre_app_default
} else {
  nombre_app <- readline(prompt = "   Ingresa el nombre de tu aplicación: ")
  # Limpiar el nombre (solo minúsculas, números y guiones)
  nombre_app <- tolower(gsub("[^a-z0-9-]", "-", nombre_app))
  cat("   Nombre final:", nombre_app, "\n")
}

cat("\n")

# ----------------------------------------------------------------------------
# PASO 5: PREPARAR ARCHIVOS PARA DESPLIEGUE
# ----------------------------------------------------------------------------

cat("📁 Paso 5: Preparando archivos para despliegue...\n")

# Verificar que existan los archivos necesarios
archivos_requeridos <- c("app.R", "global.R")
archivos_faltantes <- archivos_requeridos[!file.exists(archivos_requeridos)]

if (length(archivos_faltantes) > 0) {
  cat("   ❌ Archivos faltantes:\n")
  cat(paste0("      - ", archivos_faltantes, collapse = "\n"), "\n\n")
  stop("Despliegue cancelado: archivos faltantes")
}

cat("   ✅ Archivos principales encontrados\n")

# Verificar carpeta www (opcional pero recomendada)
if (dir.exists("www")) {
  cat("   ✅ Carpeta www/ encontrada\n")
} else {
  cat("   ⚠️  Carpeta www/ no encontrada (opcional)\n")
}

cat("\n")

# ----------------------------------------------------------------------------
# PASO 6: DESPLEGAR LA APLICACIÓN
# ----------------------------------------------------------------------------

cat("🚀 Paso 6: Desplegando la aplicación...\n\n")

cat("   Esto puede tomar varios minutos...\n")
cat("   Por favor, espera mientras se despliega la aplicación.\n\n")

# Confirmar antes de desplegar
respuesta_deploy <- readline(prompt = "   ¿Proceder con el despliegue? (s/n): ")

if (tolower(respuesta_deploy) != "s") {
  cat("\n   ⏹️  Despliegue cancelado por el usuario.\n\n")
  stop("Despliegue cancelado")
}

cat("\n")

# Ejecutar despliegue
tryCatch({
  rsconnect::deployApp(
    appDir = ".",
    appName = nombre_app,
    appTitle = "Análisis de Kruskal-Wallis",
    account = cuentas$name[1],
    forceUpdate = TRUE,
    launch.browser = TRUE
  )
  
  cat("\n")
  cat("====================================================================\n")
  cat("  ✅ ¡DESPLIEGUE COMPLETADO EXITOSAMENTE!\n")
  cat("====================================================================\n\n")
  
  # URL de la aplicación
  url_app <- paste0("https://", cuentas$name[1], ".shinyapps.io/", nombre_app, "/")
  
  cat("   🌐 URL de tu aplicación:\n")
  cat("      ", url_app, "\n\n")
  
  cat("   📊 Panel de control:\n")
  cat("      https://www.shinyapps.io/admin/#/applications\n\n")
  
  cat("   💡 Próximos pasos:\n")
  cat("      1. La aplicación se abrió automáticamente en tu navegador\n")
  cat("      2. Prueba todas las funcionalidades\n")
  cat("      3. Comparte la URL con tus usuarios\n")
  cat("      4. Monitorea el uso desde el panel de shinyapps.io\n\n")
  
  cat("====================================================================\n\n")
  
}, error = function(e) {
  cat("\n")
  cat("====================================================================\n")
  cat("  ❌ ERROR DURANTE EL DESPLIEGUE\n")
  cat("====================================================================\n\n")
  cat("   Error:\n")
  cat("   ", e$message, "\n\n")
  
  cat("   🔍 Posibles soluciones:\n")
  cat("      1. Verifica tu conexión a internet\n")
  cat("      2. Confirma que tu token de shinyapps.io es válido\n")
  cat("      3. Verifica que el nombre de la app no esté en uso\n")
  cat("      4. Revisa los logs en el panel de shinyapps.io\n\n")
  
  cat("   📚 Documentación:\n")
  cat("      https://docs.rstudio.com/shinyapps.io/\n\n")
  
  cat("====================================================================\n\n")
})

# ----------------------------------------------------------------------------
# PASO 7: INFORMACIÓN ADICIONAL
# ----------------------------------------------------------------------------

cat("📋 Información adicional:\n\n")

cat("   🔧 Configuración de la aplicación:\n")
cat("      - Puedes ajustar la memoria y las instancias desde el panel\n")
cat("      - Plan gratuito: 25 horas activas por mes\n")
cat("      - Tiempo de inactividad: 15 minutos\n\n")

cat("   🔄 Para actualizar la aplicación:\n")
cat("      - Modifica tus archivos localmente\n")
cat("      - Ejecuta este script nuevamente\n")
cat("      - La aplicación se actualizará automáticamente\n\n")

cat("   📊 Monitoreo:\n")
cat("      - Panel de shinyapps.io muestra métricas de uso\n")
cat("      - Puedes ver logs en tiempo real\n")
cat("      - Configura alertas de uso\n\n")

cat("====================================================================\n")
cat("  Script completado\n")
cat("====================================================================\n\n")